package halogo.converter;

public class NumberWordConstants {
	
	static final String ZERO = "ZERO";
	static final String ONE = "ONE";
	static final String TWO = "TWO";
	static final String THREE = "THREE";
	static final String FOUR = "FOUR";
	static final String FIVE = "FIVE";
	static final String SIX = "SIX";
	static final String SEVEN = "SEVEN";
	static final String EIGHT = "EIGHT";
	static final String NINE = "NINE";
	static final String TEN = "TEN";

	static final String ELEVEN = "ELEVEN";
	static final String TWELVE = "TWELVE";
	static final String THIRTEEN = "THIRTEEN";
	static final String FOURTEEN = "FOURTEEN";
	static final String FIFTEEN = "FIFTEEN";
	static final String SIXTEEN = "SIXTEEN";
	static final String SEVENTEEN = "SEVENTEEN";
	static final String EIGHTEEN = "EIGHTEEN";
	static final String NINETEEN = "NINETEEN";
	
	static final String TWENTY = "TWENTY";
	static final String THIRTY = "THIRTY";
	static final String FORTY = "FORTY";
	static final String FIFTY = "FIFTY";
	static final String SIXTY = "SIXTY";
	static final String SEVENTY = "SEVENTY";
	static final String EIGHTY = "EIGHTY";
	static final String NINETY = "NINETY";

	static final String HUNDRED = "HUNDRED";
	static final String THOUSAND = "THOUSAND";
	static final String MILLION = "MILLION";
	static final String BILLION = "BILLION";
	static final String TRILLION = "TRILLION";
	static final String QUADRILLION = "QUADRILLION";
	static final String QUINTILLION = "QUINTILLION";
	static final String SEXTILLION = "SEXTILLION";
	
	static final String AND = "AND";
	static final String DOLLARS = "DOLLARS";
	static final String DOLLAR = "DOLLAR";
	static final String CENTS = "CENTS";
	static final String CENT = "CENT";
	static final String POINT = "POINT";
	static final String MINUS = "MINUS";
	
	static final String smallNumbersArray[] = { ZERO,
												ONE,
												TWO,
												THREE,
												FOUR,
												FIVE,
												SIX,
												SEVEN,
												EIGHT,
												NINE,
												TEN,
												ELEVEN,
												TWELVE,
												THIRTEEN,
												FOURTEEN,
												FIFTEEN,
												SIXTEEN,
												SEVENTEEN,
												EIGHTEEN,
												NINETEEN};
	
	static final String tensArray[] = { ZERO,
										TEN,
										TWENTY,
										THIRTY,
										FORTY,
										FIFTY,
										SIXTY,
										SEVENTY,
										EIGHTY,
										NINETY };
	
	
}