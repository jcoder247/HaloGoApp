package halogo.converter;

public class Converter {

	private String amount = "0";
	private String name;

	public String getAmount() {
		return ConverterFunctions.convertNumToMoneyWords(amount);
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
