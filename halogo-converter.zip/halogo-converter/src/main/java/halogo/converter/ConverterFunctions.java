package halogo.converter;

import java.util.regex.Pattern;

public class ConverterFunctions {
	
	private static final String STANDARD_ADVICE_MESSAGE = "Please enter a valid number in dollar and cents format. For example: 123.45";
	private static final String TOO_MANY_DOTS = "There are too many dots in the number.";
	private static final String CENTS_MUST_BE_A_NUMBER = "The cents must be a number.";
	private static final String DOLLARS_MUST_BE_A_NUMBER = "The dollars must be a number.";
	
	/**
	 * Reads in a number and returns the number as words as if it represented money.
	 * 
	 * For example "123.45" becomes "ONE HUNDRED AND TWENTY-THREE DOLLARS AND FORTY-FIVE CENTS"
	 * 
	 * Does some error handling and returns advice based on the format of the entry provided.
	 * 
	 * @param number
	 * @return A String of words that describe the number. Or a message to the user providing advice on what might need to be corrected.
	 */
	public static String convertNumToMoneyWords(String number){
		String result = "";
		String strCents = "0";
		int cents = 0;
		int[] fractionOfCents = null;
		long dollars;
		String centValueWord = "";
		int[][] centsAndCentFractions = null;
				
		try{
			//If there is no number then return some advice to enter a valid number
			if(number == null || number.isEmpty()){ return STANDARD_ADVICE_MESSAGE;}
			
			//If there is more than one decimal point, then return some advice to enter a valid number
			if(number.split("\\.").length > 2){ return TOO_MANY_DOTS + " " + STANDARD_ADVICE_MESSAGE;}
			
			//Determine if there are any cents. If there are get the cents and fractions of cents.
			try{
				if(number.matches(".*\\..*") && number.split("\\.").length > 0){
					strCents = number.split("\\.")[1];
					centsAndCentFractions = splitCents(strCents);
					if(centsAndCentFractions.length > 0 && centsAndCentFractions[0].length > 0){
						cents = centsAndCentFractions[0][0];
						fractionOfCents = centsAndCentFractions[1];
					}
				}
			}catch(Exception eConvert){
				return CENTS_MUST_BE_A_NUMBER + " " + STANDARD_ADVICE_MESSAGE;
			}
			
			//Get the dollars value
			try{
				if(number.split("\\.").length > 0){
					dollars = Long.parseLong(number.split("\\.")[0]);
				}else{
					dollars = Integer.parseInt(number);
				}
			}catch(Exception eConvert){
				return DOLLARS_MUST_BE_A_NUMBER + " " + STANDARD_ADVICE_MESSAGE;
			}
			
			//Get the words for the dollar part
			String dollarValueWords = numberToWords(dollars);
			
			//Cents can be just cents or may need to broken into fractions of cents
			//For example "TEN CENTS" OR "TEN POINT ZERO FOUR FIVE CENTS"
			if(cents > 0 || 
			   fractionOfCents != null && fractionOfCents.length == 1 && fractionOfCents[0] > 0 || 
			   fractionOfCents != null && fractionOfCents.length > 1){
				if(cents > 0){
					//Case where there are 0 dollars but overall the value is negative. We want to apply the word to the cents.
					if(dollars == 0 && number.startsWith("-")){
						centValueWord = numberToWords(-cents);
					}else{
						centValueWord = numberToWords(cents);
					}
					
				}
				if(Long.parseLong(strCents) > 0 && 
						(fractionOfCents.length == 1 && fractionOfCents[0] > 0 || 
						fractionOfCents.length > 1)){
						if(cents != 0) centValueWord += " "; //Avoid getting duplicate spaces
						centValueWord += NumberWordConstants.POINT + " ";
					for(int i = 0; i < fractionOfCents.length; i++){
						if(i > 0) centValueWord +=  " ";
						centValueWord +=  numberToWords(fractionOfCents[i]);
						
					}
				}
			}
			
			//Construct the final result
			if(dollars != 0){
				result = dollarValueWords + " ";
				if(dollars == 1 || dollars == -1){
					result += NumberWordConstants.DOLLAR;
				}else{
					result += NumberWordConstants.DOLLARS;
				}
			}
			
			//Add the cents, and fractions of cents if there are any to the final result
			if(cents > 0 || 
			   fractionOfCents != null && fractionOfCents.length == 1 && fractionOfCents[0] > 0 || 
			   fractionOfCents != null && fractionOfCents.length > 1){
					if(dollars != 0 && Long.parseLong(strCents) > 0){
						result += " " + NumberWordConstants.AND + " ";
					}
					result += centValueWord;
					//If there is only one cent and no fractionOfCents, the word will be CENT.
					if((cents == 1 || cents == -1) && fractionOfCents.length == 1 && fractionOfCents[0] == 0){
						result += " " + NumberWordConstants.CENT;
					}else if(Long.parseLong(strCents) > 0){
						result += " " + NumberWordConstants.CENTS;
					}
			}
			
		}catch(Exception e){
			e.printStackTrace();
			return "Failed to convert the amount into words.";
		}
		return result;
	}
	
	
	protected static String numberToWords(long number){
		String result = "";
		
		if(number == 0){
			return NumberWordConstants.ZERO;
		}
		
		if(number < 0){
			String numberStr = "" + number;
			numberStr = numberStr.substring(1);
			result = NumberWordConstants.MINUS + " " + numberToWords(Long.parseLong(numberStr));
		}
		
		//Add QUADRILLION
		ConverterType current = largeNumberWords(new ConverterType(number, result), 1000000000000000000L, NumberWordConstants.QUINTILLION);
		
		//Add QUADRILLION
		current = largeNumberWords(current, 1000000000000000L, NumberWordConstants.QUADRILLION);
		
		//Add TRILLIONS
		current = largeNumberWords(current, 1000000000000L, NumberWordConstants.TRILLION);
		
		//Add BILLIONS
		current = largeNumberWords(current, 1000000000, NumberWordConstants.BILLION);

		//Add MILLIONS
		current = largeNumberWords(current, 1000000, NumberWordConstants.MILLION);
		
		//Add THOUSANDS
		current = largeNumberWords(current, 1000, NumberWordConstants.THOUSAND);
		number = current.getNumber();
		result = current.getResult();
		
		if ((number / 100) > 0) {
			result += numberToWords(number / 100) + " " + NumberWordConstants.HUNDRED;
		     number %= 100;
		     if(number > 0){
		    	 result += " AND ";
		     }
		}
		
		if (number > 0) {
		     if (number < 20) { 
		    	 result += NumberWordConstants.smallNumbersArray[(int) number];
	             } else { 
	            	 result += NumberWordConstants.tensArray[(int) (number / 10)]; 
	                if ((number % 10) > 0) {
	                	result += "-" + NumberWordConstants.smallNumbersArray[(int) (number % 10)];
	                }  
		     }
	     }
		
		return result;
	}
	
	
	/**
	 * Determines based on the size of the number (contained in current), if the largeNumberWord (MILLION, BILLION etc.)
	 * should be applied. If it is, applies the word along with spaces and if there will be other words following or not
	 * and adds an " AND " if required.
	 * 
	 * @param current - contains number and resulting test.
	 * @param size - the size we are checking (1000000000, 1000000000000 etc).
	 * @param largeNumberWord
	 * @return
	 */
	protected static ConverterType largeNumberWords(ConverterType current, long size, String largeNumberWord){
		
		if ((current.getNumber() / size) > 0) {
			current.setResult(current.getResult() + numberToWords(current.getNumber()/size) + " " + largeNumberWord);
			long modulus = current.getNumber()%size;
		    if(modulus > 0 ){
		    	if((current.getNumber() - current.getNumber()/size*size) > 100){
		    		current.setResult(current.getResult() + " ");
		    	}else{
		    		current.setResult(current.getResult() + " AND ");
		    	}
		    }else{
		    	 modulus = current.getNumber() % 100;
		    	 if(modulus > 0){
		    		 current.setResult(current.getResult() + " AND ");
			     }
		    }
	    	current.setNumber(current.getNumber()%size);
		}
		
		ConverterType result = new ConverterType(current.getNumber() % size, current.getResult());
		return result;
	}
	
	/**
	 * Splits the cents into an two dimensional array of size two by n.
	 * 
	 * 
	 * The first part contains the cents.
	 * The second part contains the fraction of cents.
	 * 
	 * E.g. 1045 => { {10, 0},   -cents part
	 * 					{4,5}} - fraction of cents
	 * 		885867 => { {88, 0}, -cents part
	 * 					{5,8,6,7}}- fraction of cents
	 * 		990001 => { {99, 0}, -cents part
	 * 					{0,0,0,1}}- fraction of cents
	 * 		015 => { {1}, -cents part
	 * 					{5}}- fraction of cents
	 * 
	 * @param number
	 * @return
	 * @throws Exception 
	 */
	protected static int[][] splitCents(String strNumber) throws Exception{
		int[][] result = null;
		int cents = 0;
		int[] fractionOfCents = null;
		
		//Check that strNumber only contains numbers
		Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
		if(!pattern.matcher(strNumber).matches()){
			throw new Exception("The string '" + strNumber + "' is not numberic");
		}
		
		//obtain the cents part
		char[] digits = strNumber.toCharArray();
		if(digits.length > 1){
			String strCents = Character.getNumericValue(digits[0]) + "" + Character.getNumericValue(digits[1]);
			cents = Integer.parseInt(strCents);
		}else if(digits.length == 1) {
			cents = Character.getNumericValue(digits[0]);
		}else if(digits.length == 0) {
			cents = Character.getNumericValue(0);
		}
		
		//obtain the fraction of cents part
		if(digits.length > 2){
			fractionOfCents = new int[digits.length - 2];
			for (int i = 2; i < digits.length; i++){
				fractionOfCents[i - 2] = Character.getNumericValue(digits[i]);
			}
		}else if(fractionOfCents == null){
			fractionOfCents = new int[1];
			fractionOfCents[0] = 0;
		}
		
		result = new int[2][fractionOfCents.length];
		result[0][0] = cents;
		result[1] = fractionOfCents;
		
		return result;
	}
	
}