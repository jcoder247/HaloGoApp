package halogo.converter;

/**
 * A data type used by the Converter class to store:
 * 
 * number - the numeric value we want to convert to words.
 * result - the words relating to the number.
 * 
 * @author PaulBuckley
 *
 */
public class ConverterType {

	private long number = 0;
	
	private String result = "";

	
	public long getNumber() {
		return number;
	}

	public void setNumber(long number) {
		this.number = number;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public ConverterType(long number, String result) {
		super();
		this.number = number;
		this.result = result;
	}
}